$('#testimonial_section').owlCarousel({
	items: 3,
	loop: true,	
	margin: 30,
	nav: true,
	dots: false	,
	center:true
    // autoplay:true,
    // autoplaySpeed: 6000,
    // autoplayTimeout: 6000,
    // slideTransition: 'linear',

})